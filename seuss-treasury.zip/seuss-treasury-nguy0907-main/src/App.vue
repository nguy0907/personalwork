<template>
  <div class="container">
    <router-link to="/"> Books </router-link>
     <router-link to="/quotes"> Quotes </router-link>
     <router-view/>
  </div>
</template>

<script></script>

<style></style>